package dev.emi.trinkets.payload;

import dev.emi.trinkets.TrinketsNetwork;
import dev.emi.trinkets.api.SlotGroup;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_2487;
import net.minecraft.class_7924;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SyncSlotsPayload(Map<class_1299<?>, Map<String, SlotGroup>> map) implements class_8710 {
	public static final class_9139<class_9129, SyncSlotsPayload> CODEC = class_9135.method_56377(
			(x) -> (Map<class_1299<?>, Map<String, SlotGroup>>) new HashMap<class_1299<?>, Map<String, SlotGroup>>(x),
			class_9135.method_56365(class_7924.field_41266),
			class_9135.method_56377(HashMap::new, class_9135.field_48554, class_9135.field_48556.method_56432(SlotGroup::read, (x) -> {
				var nbt = new class_2487();
				x.write(nbt);
				return nbt;
			}))
			).method_56432(SyncSlotsPayload::new, SyncSlotsPayload::map);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return TrinketsNetwork.SYNC_SLOTS;
	}
}
