package dev.emi.trinkets.payload;

import dev.emi.trinkets.TrinketsNetwork;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SyncInventoryPayload(int entityId, Map<String, class_1799> contentUpdates, Map<String, class_2487> inventoryUpdates) implements class_8710 {
	public static final class_9139<class_9129, SyncInventoryPayload> CODEC = class_9139.method_56436(
			class_9135.field_48550,
			SyncInventoryPayload::entityId,
			class_9135.method_56377(HashMap::new, class_9135.field_48554, class_1799.field_49268),
			SyncInventoryPayload::contentUpdates,
			class_9135.method_56377(HashMap::new, class_9135.field_48554, class_9135.field_48556),
			SyncInventoryPayload::inventoryUpdates,
			SyncInventoryPayload::new);
	@Override
	public class_9154<? extends class_8710> method_56479() {
		return TrinketsNetwork.SYNC_INVENTORY;
	}
}
