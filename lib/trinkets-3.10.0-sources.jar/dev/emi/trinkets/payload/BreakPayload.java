package dev.emi.trinkets.payload;

import dev.emi.trinkets.TrinketsNetwork;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;


public record BreakPayload(int entityId, String group, String slot, int index) implements class_8710 {
	public static final class_9139<class_9129, BreakPayload> CODEC = class_9139.method_56905(
			class_9135.field_48550,
			BreakPayload::entityId,
			class_9135.field_48554,
			BreakPayload::group,
			class_9135.field_48554,
			BreakPayload::slot,
			class_9135.field_48550,
			BreakPayload::index,
			BreakPayload::new
	);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return TrinketsNetwork.BREAK;
	}
}
