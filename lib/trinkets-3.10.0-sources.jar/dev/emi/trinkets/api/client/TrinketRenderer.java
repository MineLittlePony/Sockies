package dev.emi.trinkets.api.client;

import dev.emi.trinkets.api.SlotReference;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.minecraft.class_922;

public interface TrinketRenderer {

	/**
	 * Renders the Trinket
	 *
	 * @param stack The {@link class_1799} for the Trinket being rendered
	 * @param slotReference The exact slot for the item being rendered
	 * @param contextModel The model this Trinket is being rendered on
	 */
	void render(class_1799 stack, SlotReference slotReference, class_583<? extends class_1309> contextModel,
				class_4587 matrices, class_4597 vertexConsumers, int light, class_1309 entity,
				float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw,
				float headPitch);

	/**
	 * Rotates the rendering for the models based on the entity's poses and movements. This will do
	 * nothing if the entity render object does not implement {@link class_922} or if the
	 * model does not implement {@link class_572}).
	 *
	 * @param entity The wearer of the trinket
	 * @param model The model to align to the body movement
	 */
	@SuppressWarnings("unchecked")
	static void followBodyRotations(final class_1309 entity, final class_572<class_1309> model) {

		class_897<? super class_1309> render = class_310.method_1551()
				.method_1561().method_3953(entity);

		if (render instanceof class_922) {
			//noinspection unchecked
			class_922<class_1309, class_583<class_1309>> livingRenderer =
					(class_922<class_1309, class_583<class_1309>>) render;
			class_583<class_1309> entityModel = livingRenderer.method_4038();

			if (entityModel instanceof class_572) {
				class_572<class_1309> bipedModel = (class_572<class_1309>) entityModel;
				bipedModel.method_2818(model);
			}
		}
	}

	/**
	 * Translates the rendering context to the center of the player's face
	 */
	static void translateToFace(class_4587 matrices, class_591<class_742> model,
			class_742 player, float headYaw, float headPitch) {

		if (player.method_20232() || player.method_6128()) {
			matrices.method_22907(class_7833.field_40718.rotationDegrees(model.field_3398.field_3674));
			matrices.method_22907(class_7833.field_40716.rotationDegrees(headYaw));
			matrices.method_22907(class_7833.field_40714.rotationDegrees(-45.0F));
		} else {

			if (player.method_18276() && !model.field_3449) {
				matrices.method_46416(0.0F, 0.25F, 0.0F);
			}
			matrices.method_22907(class_7833.field_40716.rotationDegrees(headYaw));
			matrices.method_22907(class_7833.field_40714.rotationDegrees(headPitch));
		}
		matrices.method_46416(0.0F, -0.25F, -0.3F);
	}

	/**
	 * Translates the rendering context to the center of the player's chest/torso segment
	 */
	static void translateToChest(class_4587 matrices, class_591<class_742> model,
			class_742 player) {

		if (player.method_18276() && !model.field_3449 && !player.method_5681()) {
			matrices.method_46416(0.0F, 0.2F, 0.0F);
			matrices.method_22907(class_7833.field_40714.rotation(model.field_3391.field_3654));
		}
		matrices.method_22907(class_7833.field_40716.rotation(model.field_3391.field_3675));
		matrices.method_46416(0.0F, 0.4F, -0.16F);
	}

	/**
	 * Translates the rendering context to the center of the bottom of the player's right arm
	 */
	static void translateToRightArm(class_4587 matrices, class_591<class_742> model,
			class_742 player) {

		if (player.method_18276() && !model.field_3449 && !player.method_5681()) {
			matrices.method_46416(0.0F, 0.2F, 0.0F);
		}
		matrices.method_22907(class_7833.field_40716.rotation(model.field_3391.field_3675));
		matrices.method_46416(-0.3125F, 0.15625F, 0.0F);
		matrices.method_22907(class_7833.field_40718.rotation(model.field_3401.field_3674));
		matrices.method_22907(class_7833.field_40716.rotation(model.field_3401.field_3675));
		matrices.method_22907(class_7833.field_40714.rotation(model.field_3401.field_3654));
		matrices.method_46416(-0.0625F, 0.625F, 0.0F);
	}

	/**
	 * Translates the rendering context to the center of the bottom of the player's left arm
	 */
	static void translateToLeftArm(class_4587 matrices, class_591<class_742> model,
			class_742 player) {

		if (player.method_18276() && !model.field_3449 && !player.method_5681()) {
			matrices.method_46416(0.0F, 0.2F, 0.0F);
		}
		matrices.method_22907(class_7833.field_40716.rotation(model.field_3391.field_3675));
		matrices.method_46416(0.3125F, 0.15625F, 0.0F);
		matrices.method_22907(class_7833.field_40718.rotation(model.field_27433.field_3674));
		matrices.method_22907(class_7833.field_40716.rotation(model.field_27433.field_3675));
		matrices.method_22907(class_7833.field_40714.rotation(model.field_27433.field_3654));
		matrices.method_46416(0.0625F, 0.625F, 0.0F);
	}

	/**
	 * Translates the rendering context to the center of the bottom of the player's right leg
	 */
	static void translateToRightLeg(class_4587 matrices, class_591<class_742> model,
			class_742 player) {

		if (player.method_18276() && !model.field_3449 && !player.method_5681()) {
			matrices.method_46416(0.0F, 0.0F, 0.25F);
		}
		matrices.method_46416(-0.125F, 0.75F, 0.0F);
		matrices.method_22907(class_7833.field_40718.rotation(model.field_3392.field_3674));
		matrices.method_22907(class_7833.field_40716.rotation(model.field_3392.field_3675));
		matrices.method_22907(class_7833.field_40714.rotation(model.field_3392.field_3654));
		matrices.method_46416(0.0F, 0.75F, 0.0F);
	}

	/**
	 * Translates the rendering context to the center of the bottom of the player's left leg
	 */
	static void translateToLeftLeg(class_4587 matrices, class_591<class_742> model,
			class_742 player) {

		if (player.method_18276() && !model.field_3449 && !player.method_5681()) {
			matrices.method_46416(0.0F, 0.0F, 0.25F);
		}
		matrices.method_46416(0.125F, 0.75F, 0.0F);
		matrices.method_22907(class_7833.field_40718.rotation(model.field_3397.field_3674));
		matrices.method_22907(class_7833.field_40716.rotation(model.field_3397.field_3675));
		matrices.method_22907(class_7833.field_40714.rotation(model.field_3397.field_3654));
		matrices.method_46416(0.0F, 0.75F, 0.0F);
	}
}
