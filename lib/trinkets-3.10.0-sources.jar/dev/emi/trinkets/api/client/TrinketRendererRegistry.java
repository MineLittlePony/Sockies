package dev.emi.trinkets.api.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1792;

public class TrinketRendererRegistry {

	private static final Map<class_1792, TrinketRenderer> RENDERERS = new HashMap<>();

	/**
	 * Registers a trinket renderer for the provided item
	 */
	public static void registerRenderer(class_1792 item, TrinketRenderer trinketRenderer) {
		RENDERERS.put(item, trinketRenderer);
	}

	public static Optional<TrinketRenderer> getRenderer(class_1792 item) {
		return Optional.ofNullable(RENDERERS.get(item));
	}
}
