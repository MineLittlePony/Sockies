package dev.emi.trinkets.mixin;

import dev.emi.trinkets.TrinketFeatureRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3887;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds the trinket feature renderer to the list of living entity features
 *
 * @author C4
 * @author powerboat9
 */
@Environment(EnvType.CLIENT)
@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin {
    @Invoker("addFeature")
    public abstract boolean invokeAddFeature(class_3887<?, ?> feature);

	@Inject(at = @At("RETURN"), method = "<init>")
	public void init(class_5617.class_5618 ctx, class_583<?> model, float shadowRadius, CallbackInfo info) {
        this.invokeAddFeature(new TrinketFeatureRenderer<>((class_922<?, ?>) (Object) this));
	}
}
