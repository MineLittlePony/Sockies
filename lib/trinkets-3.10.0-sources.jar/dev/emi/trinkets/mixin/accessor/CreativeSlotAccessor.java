package dev.emi.trinkets.mixin.accessor;

import net.minecraft.class_1735;
import net.minecraft.class_481.class_484;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * You'll access widen this into being accessible but won't make its field accessible? Yes.
 */
@Mixin(class_484.class)
public interface CreativeSlotAccessor {
	
	@Accessor("slot")
	public class_1735 getSlot();
}
