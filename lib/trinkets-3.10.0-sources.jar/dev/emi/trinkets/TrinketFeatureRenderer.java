package dev.emi.trinkets;

import dev.emi.trinkets.api.TrinketsApi;
import dev.emi.trinkets.api.client.TrinketRendererRegistry;
import net.minecraft.class_1309;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;

public class TrinketFeatureRenderer<T extends class_1309, M extends class_583<T>> extends class_3887<T, M> {

	public TrinketFeatureRenderer(class_3883<T, M> context) {
		super(context);
	}

	@Override
	public void render(class_4587 matrices, class_4597 vertexConsumers, int light, T entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
		TrinketsApi.getTrinketComponent(entity).ifPresent(component ->
				component.forEach((slotReference, stack) ->
						TrinketRendererRegistry.getRenderer(stack.method_7909()).ifPresent(renderer -> {
							matrices.method_22903();
							renderer.render(stack, slotReference, this.method_17165(), matrices, vertexConsumers,
									light, entity, limbAngle, limbDistance, tickDelta, animationProgress, headYaw, headPitch);
							matrices.method_22909();
						})
				)
		);
	}
}
